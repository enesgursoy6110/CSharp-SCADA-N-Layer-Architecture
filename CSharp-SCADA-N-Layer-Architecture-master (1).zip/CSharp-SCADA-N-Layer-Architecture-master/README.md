# CSharp-SCADA-N-Layer-Architecture

[Linkedin Trailer Video Link](https://www.linkedin.com/feed/update/urn:li:activity:6655861343087804416/)

SCADA project suitable for C# and ADO.NET layered architecture. There is a Console application example that writes data between Modbus TCP-IP and Microsoft SQL Server, you can use it in the background like OPC-UA if you want.
You can develop different and sustainable Automation SCADA projects by designing a visual interface only with Windows Form.
